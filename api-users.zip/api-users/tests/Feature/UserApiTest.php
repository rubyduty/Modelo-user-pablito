<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class UserApiTest extends TestCase
{
    use RefreshDatabase;

    private function makeUser(): User
    {
        return User::create([
            'username' => 'ruben',
            'email' => 'ruben@example.com',
            'password' => 'password123',
        ]);
    }

    public function test_get_devuelve_los_diez_primeros_paginados(): void
    {
        User::factory(15)->create();

        $this->getJson('/api/users')
            ->assertOk()
            ->assertJsonCount(10, 'data')
            ->assertJsonPath('meta.per_page', 10)
            ->assertJsonPath('meta.total', 15)
            ->assertJsonMissingPath('data.0.password');

        $this->getJson('/api/users?page=2')->assertOk()->assertJsonCount(5, 'data');
    }

    public function test_create_crea_un_usuario_con_la_contrasena_hasheada(): void
    {
        $this->postJson('/api/users', [
            'username' => 'nuevo',
            'email' => 'nuevo@example.com',
            'password' => 'secreto123',
        ])->assertCreated()->assertJsonPath('data.username', 'nuevo');

        $user = User::where('email', 'nuevo@example.com')->firstOrFail();
        $this->assertNotSame('secreto123', $user->password);
        $this->assertTrue(Hash::check('secreto123', $user->password));
    }

    public function test_create_valida_campos_y_duplicados(): void
    {
        $this->makeUser();

        $this->postJson('/api/users', [
            'username' => 'ruben',
            'email' => 'ruben@example.com',
            'password' => '123',
        ])->assertUnprocessable()->assertJsonValidationErrors(['username', 'email', 'password']);
    }

    public function test_login_devuelve_los_datos_del_usuario(): void
    {
        $this->makeUser();

        $this->postJson('/api/users/login', ['email' => 'ruben@example.com', 'password' => 'password123'])
            ->assertOk()
            ->assertJsonPath('data.email', 'ruben@example.com')
            ->assertJsonPath('data.username', 'ruben');
    }

    public function test_login_con_credenciales_incorrectas_devuelve_401(): void
    {
        $this->makeUser();

        $this->postJson('/api/users/login', ['email' => 'ruben@example.com', 'password' => 'mala'])
            ->assertUnauthorized();
        $this->postJson('/api/users/login', ['email' => 'noexiste@example.com', 'password' => 'password123'])
            ->assertUnauthorized();
    }

    public function test_update_username(): void
    {
        $user = $this->makeUser();

        $this->putJson('/api/users/username', [
            'email' => 'ruben@example.com',
            'password' => 'password123',
            'username' => 'ruben_dev',
        ])->assertOk()->assertJsonPath('data.username', 'ruben_dev');

        $this->assertSame('ruben_dev', $user->fresh()->username);
    }

    public function test_update_email(): void
    {
        $user = $this->makeUser();

        $this->putJson('/api/users/email', [
            'email' => 'ruben@example.com',
            'password' => 'password123',
            'new_email' => 'ruben.nuevo@example.com',
        ])->assertOk()->assertJsonPath('data.email', 'ruben.nuevo@example.com');

        $this->assertSame('ruben.nuevo@example.com', $user->fresh()->email);
    }

    public function test_update_password(): void
    {
        $user = $this->makeUser();

        $this->putJson('/api/users/password', [
            'email' => 'ruben@example.com',
            'password' => 'password123',
            'new_password' => 'nuevaClave456',
        ])->assertOk();

        $this->assertTrue(Hash::check('nuevaClave456', $user->fresh()->password));
        $this->postJson('/api/users/login', ['email' => 'ruben@example.com', 'password' => 'password123'])
            ->assertUnauthorized();
    }

    public function test_updates_con_contrasena_incorrecta_no_cambian_nada(): void
    {
        $user = $this->makeUser();

        $this->putJson('/api/users/username', [
            'email' => 'ruben@example.com',
            'password' => 'mala',
            'username' => 'hacker',
        ])->assertUnauthorized();

        $this->assertSame('ruben', $user->fresh()->username);
    }

    public function test_delete_elimina_el_usuario(): void
    {
        $user = $this->makeUser();

        $this->deleteJson('/api/users', ['email' => 'ruben@example.com', 'password' => 'mala'])
            ->assertUnauthorized();
        $this->assertModelExists($user);

        $this->deleteJson('/api/users', ['email' => 'ruben@example.com', 'password' => 'password123'])
            ->assertOk();
        $this->assertModelMissing($user);
    }
}
