<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Crea dos usuarios con credenciales conocidas (para probar el login
     * desde Postman) y diez usuarios aleatorios para que se vea la paginación.
     */
    public function run(): void
    {
        // La contraseña se guarda hasheada automáticamente gracias al cast
        // 'password' => 'hashed' del modelo User.
        User::create([
            'username' => 'ruben',
            'email' => 'ruben@example.com',
            'password' => 'password123',
        ]);

        User::create([
            'username' => 'maria',
            'email' => 'maria@example.com',
            'password' => 'password123',
        ]);

        User::factory(10)->create();
    }
}
