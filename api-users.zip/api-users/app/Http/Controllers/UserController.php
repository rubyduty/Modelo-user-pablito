<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * get: devuelve la paginación de los usuarios, de diez en diez.
     * GET /api/users?page=1
     */
    public function get(): AnonymousResourceCollection
    {
        return UserResource::collection(User::orderBy('id')->paginate(10));
    }

    /**
     * create: crea un usuario en la base de datos.
     * POST /api/users
     */
    public function create(Request $request): JsonResponse
    {
        $data = $request->validate([
            'username' => ['required', 'string', 'max:255', 'unique:users,username'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        $user = User::create($data);

        return $this->userResponse($user, 'Usuario creado correctamente.', 201);
    }

    /**
     * login: devuelve los datos de un usuario a partir de su email y contraseña.
     * POST /api/users/login
     */
    public function login(Request $request): JsonResponse
    {
        $user = $this->authenticate($request);

        return $this->userResponse($user, 'Login correcto.');
    }

    /**
     * update_username: actualiza el username (requiere email y contraseña).
     * PUT /api/users/username
     */
    public function updateUsername(Request $request): JsonResponse
    {
        $user = $this->authenticate($request);

        $data = $request->validate([
            'username' => ['required', 'string', 'max:255', Rule::unique('users', 'username')->ignore($user->id)],
        ]);

        $user->update(['username' => $data['username']]);

        return $this->userResponse($user, 'Username actualizado correctamente.');
    }

    /**
     * update_email: actualiza el email (requiere email y contraseña).
     * PUT /api/users/email
     */
    public function updateEmail(Request $request): JsonResponse
    {
        $user = $this->authenticate($request);

        $data = $request->validate([
            'new_email' => ['required', 'string', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
        ]);

        $user->update(['email' => $data['new_email']]);

        return $this->userResponse($user, 'Email actualizado correctamente.');
    }

    /**
     * update_password: actualiza la contraseña (requiere email y contraseña actual).
     * PUT /api/users/password
     */
    public function updatePassword(Request $request): JsonResponse
    {
        $user = $this->authenticate($request);

        $data = $request->validate([
            'new_password' => ['required', 'string', 'min:8'],
        ]);

        // El cast 'hashed' del modelo se encarga de hashear la nueva contraseña.
        $user->update(['password' => $data['new_password']]);

        return $this->userResponse($user, 'Contraseña actualizada correctamente.');
    }

    /**
     * delete: elimina el usuario (requiere email y contraseña).
     * DELETE /api/users
     */
    public function delete(Request $request): JsonResponse
    {
        $user = $this->authenticate($request);

        $user->delete();

        return response()->json([
            'message' => 'Usuario eliminado correctamente.',
        ]);
    }

    /**
     * Valida email + contraseña y devuelve el usuario al que pertenecen.
     * Si no coinciden responde 401 sin indicar cuál de los dos falla,
     * para no revelar qué emails están registrados.
     */
    private function authenticate(Request $request): User
    {
        $credentials = $request->validate([
            'email' => ['required', 'string', 'email'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $credentials['email'])->first();

        if (! $user || ! Hash::check($credentials['password'], $user->password)) {
            throw new HttpResponseException(response()->json([
                'message' => 'Credenciales incorrectas.',
            ], 401));
        }

        return $user;
    }

    /**
     * Respuesta JSON homogénea: { message, data: { ...usuario } }.
     */
    private function userResponse(User $user, string $message, int $status = 200): JsonResponse
    {
        return (new UserResource($user))
            ->additional(['message' => $message])
            ->response()
            ->setStatusCode($status);
    }
}
