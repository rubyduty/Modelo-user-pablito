<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API del modelo User
|--------------------------------------------------------------------------
| Todas las rutas llevan el prefijo /api (lo añade Laravel automáticamente).
| Las rutas que reciben email + contraseña tienen un límite de 60 peticiones
| por minuto para dificultar ataques de fuerza bruta.
*/

Route::prefix('users')->controller(UserController::class)->name('users.')->group(function () {
    Route::get('/', 'get')->name('get');
    Route::post('/', 'create')->name('create');

    Route::middleware('throttle:60,1')->group(function () {
        Route::post('/login', 'login')->name('login');
        Route::put('/username', 'updateUsername')->name('update_username');
        Route::put('/email', 'updateEmail')->name('update_email');
        Route::put('/password', 'updatePassword')->name('update_password');
        Route::delete('/', 'delete')->name('delete');
    });
});
