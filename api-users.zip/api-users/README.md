# API Users – Laravel 12

API REST en Laravel 12 para gestionar el modelo `User` (username, email y contraseña), con seeder, tests automáticos y colección de Postman.

## Requisitos

- PHP 8.2 o superior con las extensiones `pdo_sqlite` y `sqlite3` activadas
- Composer

> Si al migrar sale `could not find driver`, abre tu `php.ini` (en XAMPP: `C:\xampp\php\php.ini`), quita el `;` delante de `extension=pdo_sqlite` y `extension=sqlite3` y vuelve a intentarlo.

## Instalación

```bash
git clone <URL-del-repositorio>
cd api-users
composer install
copy .env.example .env        # en Linux/Mac: cp .env.example .env
php artisan key:generate
php artisan migrate --seed    # si pregunta si crear database.sqlite, responde "yes"
php artisan serve
```

La API queda disponible en `http://127.0.0.1:8000/api`.

Para dejar la base de datos como al principio: `php artisan migrate:fresh --seed`.

## Endpoints

| Función           | Método | URL                        | Body (JSON)                                   | Respuesta OK |
|-------------------|--------|----------------------------|-----------------------------------------------|--------------|
| `get`             | GET    | `/api/users?page=1`        | –                                             | 200          |
| `create`          | POST   | `/api/users`               | `username`, `email`, `password`               | 201          |
| `login`           | POST   | `/api/users/login`         | `email`, `password`                           | 200          |
| `update_username` | PUT    | `/api/users/username`      | `email`, `password`, `username` (nuevo)       | 200          |
| `update_email`    | PUT    | `/api/users/email`         | `email`, `password`, `new_email`              | 200          |
| `update_password` | PUT    | `/api/users/password`      | `email`, `password`, `new_password`           | 200          |
| `delete`          | DELETE | `/api/users`               | `email`, `password`                           | 200          |

Errores:

- **401** – el email y la contraseña no coinciden con ningún usuario (no se indica cuál de los dos falla, para no revelar qué emails existen).
- **422** – error de validación (campo obligatorio vacío, email no válido, contraseña de menos de 8 caracteres, username o email ya registrados…).

Todas las rutas `/api/*` responden siempre en JSON. La contraseña se guarda hasheada con bcrypt y nunca se devuelve en las respuestas. Las rutas que reciben credenciales tienen un límite de 60 peticiones por minuto.

### Ejemplos

`POST /api/users/login`

```json
{
    "email": "ruben@example.com",
    "password": "password123"
}
```

Respuesta:

```json
{
    "data": {
        "id": 1,
        "username": "ruben",
        "email": "ruben@example.com",
        "created_at": "2026-09-30T18:00:00.000000Z",
        "updated_at": "2026-09-30T18:00:00.000000Z"
    },
    "message": "Login correcto."
}
```

`GET /api/users` devuelve los diez primeros usuarios en `data`, y la información de la paginación en `links` y `meta` (`current_page`, `last_page`, `per_page`, `total`…).

## Seeder

`database/seeders/UserSeeder.php` crea:

| username | email               | password      |
|----------|---------------------|---------------|
| ruben    | ruben@example.com   | password123   |
| maria    | maria@example.com   | password123   |

y además 10 usuarios aleatorios (con la factory), para que se vea la paginación en dos páginas.

## Postman

Importa `postman/API_Users.postman_collection.json` en Postman (**Import → File**).

- La carpeta **Usuarios** recorre todas las llamadas en orden: listar, crear, login, actualizar username, email y contraseña, y eliminar. Se puede lanzar entera con el *Collection Runner* y deja la base de datos como estaba.
- La carpeta **Errores (ejemplos)** muestra respuestas 401 y 422.
- La variable de colección `base_url` vale `http://127.0.0.1:8000/api`.

Cada petición lleva tests que comprueban el código de estado y los datos devueltos.

## Tests

```bash
php artisan test
```

Los tests (`tests/Feature/UserApiTest.php`) prueban cada endpoint, incluidos los casos de error.

## Archivos principales

```
app/Http/Controllers/UserController.php   Lógica de los 7 endpoints
app/Http/Resources/UserResource.php       Formato JSON del usuario (sin contraseña)
app/Models/User.php                       Modelo User
routes/api.php                            Rutas de la API
bootstrap/app.php                         Registro de routes/api.php y errores en JSON
database/migrations/..._create_users_table.php
database/seeders/UserSeeder.php
database/factories/UserFactory.php
postman/API_Users.postman_collection.json
tests/Feature/UserApiTest.php
```
